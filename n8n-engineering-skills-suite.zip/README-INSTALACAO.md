# n8n Engineering Skills Suite for Claude

A modular set of Claude Skills for professional n8n engineering. It contains one **mother Skill (router)** and ten specialist Skills. The shared operating principle is explicit: **prioritize quality of delivery over speed**. Claude must analyze, plan, build, review, and validate carefully rather than rush to a superficial result.

## Package contents

- `n8n-skill-router.zip` — mother Skill. Classifies requests and selects the relevant specialist skills.
- `n8n-workflow-architecture.zip` — architecture and technical design.
- `n8n-workflow-builder.zip` — creating and modifying workflows.
- `n8n-api-webhooks.zip` — REST/GraphQL, OAuth, APIs, and webhooks.
- `n8n-code-data.zip` — JavaScript, expressions, and data transformation.
- `n8n-ai-workflows.zip` — AI agents, LLMs, tools, memory, and RAG.
- `n8n-reliability-errors.zip` — retries, idempotency, errors, recovery, and monitoring.
- `n8n-debugging-optimization.zip` — debugging, root-cause analysis, and performance.
- `n8n-security-credentials.zip` — secrets, permissions, privacy, and hardening.
- `n8n-testing-validation.zip` — test planning, regression, and release readiness.
- `n8n-documentation-handoff.zip` — documentation, runbooks, and handoff.

## Important: install each inner ZIP separately

The outer ZIP is a delivery bundle. **Do not upload the outer ZIP to Claude as one Skill.** Claude expects one ZIP per Skill, with the skill folder at the root of that ZIP. Upload the 11 inner ZIPs individually through Claude's Skills interface.

Suggested installation order:

1. `n8n-skill-router.zip` (mother Skill)
2. `n8n-workflow-architecture.zip`
3. `n8n-workflow-builder.zip`
4. `n8n-api-webhooks.zip`
5. `n8n-code-data.zip`
6. `n8n-ai-workflows.zip`
7. `n8n-reliability-errors.zip`
8. `n8n-debugging-optimization.zip`
9. `n8n-security-credentials.zip`
10. `n8n-testing-validation.zip`
11. `n8n-documentation-handoff.zip`

Enable the mother Skill and the specialist Skills you expect Claude to use. For the complete suite, enable all of them. Then start a new conversation and ask Claude to inspect the enabled n8n engineering skills and apply the router to your next task.

## How the mother Skill works

The mother Skill is a decision guide, not a software loader. It classifies the task and specifies the specialist Skills that should apply. Claude's own Skills discovery decides which enabled Skills to load; one Skill cannot guarantee or forcibly execute another Skill. The specialists therefore have precise descriptions and independent activation criteria. When more than one is useful, Claude can compose their guidance.

If only the mother Skill is installed, it can still provide routing advice, but the detailed specialist instructions are not available. Install the relevant specialist ZIPs too.

## Install in Claude

1. Open Claude and go to **Customize / Settings → Skills** (the exact label can vary by interface/version).
2. Choose **Create skill** or **Upload a skill**.
3. Upload one inner ZIP file.
4. Repeat for each Skill you want to install.
5. Toggle the skills on. Enable Code execution and file creation if the feature requires it in your Claude environment.

Official instructions: https://support.claude.com/en/articles/12512198-how-to-create-custom-skills

## Example activation test

After installation, try:

> Quero criar um workflow no n8n que receba eventos por webhook, valide os dados, consulte uma API externa, grave o resultado e envie uma notificação no Telegram. Antes de implementar, analise a arquitetura. Priorize qualidade acima de velocidade, proteja credenciais, trate duplicidades e falhas, teste os caminhos principais e informe claramente o que foi ou não validado.

Expected routing: architecture + builder + API/webhooks + security + reliability + testing; add code/data if custom mapping is needed.

## Quality rule shared by every Skill

Quality outranks speed. Do not rush, skip inspection, invent node settings, assume tool access, leak secrets, or claim tests that were not run. Report what is implemented, what was actually tested, and what remains unverified.

## Compatibility and limits

These are instruction packages, not connectors. They do not create n8n access, MCP connections, API credentials, or permissions. Claude can act directly only when the relevant connector/tools are connected and authorized. Always review the effects before enabling production workflows or performing irreversible actions.
