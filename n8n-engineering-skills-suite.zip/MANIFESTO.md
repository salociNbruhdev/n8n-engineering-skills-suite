# Manifesto das Skills

| ZIP | Função |
|---|---|
| `n8n-skill-router.zip` | n8n Skill Router (Mother Skill) |
| `n8n-workflow-architecture.zip` | n8n Workflow Architecture |
| `n8n-workflow-builder.zip` | n8n Workflow Builder |
| `n8n-api-webhooks.zip` | n8n API and Webhook Integrations |
| `n8n-code-data.zip` | n8n Code and Data Transformation |
| `n8n-ai-workflows.zip` | n8n AI and Agent Workflows |
| `n8n-reliability-errors.zip` | n8n Reliability and Error Handling |
| `n8n-debugging-optimization.zip` | n8n Debugging and Optimization |
| `n8n-security-credentials.zip` | n8n Security and Credentials |
| `n8n-testing-validation.zip` | n8n Testing and Validation |
| `n8n-documentation-handoff.zip` | n8n Documentation and Handoff |
