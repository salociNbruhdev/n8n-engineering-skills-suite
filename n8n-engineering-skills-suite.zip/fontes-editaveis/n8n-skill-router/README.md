# n8n Skill Router (Mother Skill)

Install this ZIP as one individual Claude Skill. Upload the ZIP containing the `n8n-skill-router/` folder. Enable it alongside the n8n Skill Router for best routing behavior.
