---
name: n8n-api-webhooks
description: Connects n8n to REST and GraphQL APIs, SaaS services, OAuth, API keys, webhooks, pagination, rate limits, request signing, and external integration contracts.
---

# n8n API and Webhook Integrations

## Purpose

Engineer reliable integrations between n8n and external services. Use this skill for HTTP Request nodes, REST/GraphQL APIs, OAuth, API keys, webhooks, SaaS platforms, pagination, rate limits, and request/response troubleshooting.

## Non-negotiable delivery standard: quality over speed

The user's explicit priority is **quality of delivery over speed of execution**. Never rush, skip analysis, omit validation, or choose a fragile shortcut merely to finish sooner. Spend the necessary effort on understanding, architecture, implementation, review, and testing. A smaller correct solution is preferable to a large fragile one; a robust solution is preferable to a fast but unreliable one.

Apply these rules on every task:
- Understand the requested outcome and constraints before changing anything.
- Inspect the actual n8n instance, workflow, node versions, available tools, and integration documentation when access is available. Do not invent access, capabilities, node parameters, or test results.
- Prefer official, current documentation and verify version-sensitive behavior.
- Preserve existing behavior unless the user explicitly asks to change it. Inspect before editing and protect against destructive changes.
- Design for security, reliability, observability, maintainability, and sensible resource use.
- Validate the actual result. Distinguish structural checks, dry runs, test executions, and production verification.
- Never claim completion when an essential requirement remains unimplemented or untested. Report limitations and unresolved risks plainly.

## Execution and safety rules

Use available n8n/MCP/API tools only when they are actually present and authorized. Inspect tool descriptions and input requirements; use the narrowest suitable operation. Do not fabricate tool names or parameters. Do not expose credentials, tokens, secrets, or personal data in outputs or logs. Use n8n credential objects or approved secret stores rather than hardcoding secrets.

Before destructive or externally consequential actions (deleting data/workflows, replacing production configuration, sending messages to real recipients, charging money, publishing content, or activating a production workflow), inspect the impact and obtain explicit user authorization unless the user has already clearly authorized that exact action. Prefer backups, copies, test data, and reversible changes.

When information is missing, make a reasonable, low-risk assumption if it does not materially affect correctness. Ask one concise question only when an essential decision cannot safely be inferred. State material assumptions.

## Definition of done

A task is complete only when the requested outcome is implemented or the remaining blockers are explicit; configuration and connections have been reviewed; representative success and failure paths have been considered; security and operational risks have been checked; and the user receives a truthful summary of what changed, what was tested, what was not tested, and what remains.

## Integration discovery

- Identify the official API documentation, base URL, API version, authentication method, scopes, required headers, content types, and rate limits.
- Confirm the exact endpoint, HTTP method, path/query parameters, request body, response schema, pagination model, and error format.
- Check whether n8n has a maintained native node for the service. Prefer a native node when it provides the required operation and is supported; use HTTP Request when it offers better coverage or control.
- Verify current API behavior. Do not infer undocumented endpoints or assume old examples still work.
- Identify sandbox/test environments and avoid production writes during discovery.

## Request engineering

- Use the least-privileged credential and the n8n credential system.
- Set appropriate timeouts and request headers.
- Handle URL encoding, JSON serialization, multipart uploads, binary data, and content types correctly.
- Avoid putting secrets in query strings unless the API explicitly requires it; redact them from logs and examples.
- Validate status codes and response bodies, including non-2xx responses.
- Handle empty responses, malformed JSON, partial results, and changed schemas.
- Use pagination based on the API's actual cursor, page, offset, or link contract.
- Respect rate-limit headers and use bounded backoff for 429 and transient failures.
- Distinguish retryable failures (network errors, selected 5xx, 429) from permanent failures (invalid request, forbidden, schema mismatch).

## Webhook engineering

- Verify whether the provider requires a challenge handshake, signature/HMAC validation, IP restrictions, or a specific response deadline.
- Validate incoming payloads and reject malformed or unauthenticated requests.
- Respond promptly when the provider has strict timeout requirements; move longer work to an asynchronous follow-up when appropriate.
- Design for repeated delivery and out-of-order events. Use stable event IDs or business keys for deduplication.
- Avoid returning secrets or internal errors to webhook callers.
- Separate test and production webhook endpoints and confirm registration behavior before activation.

## OAuth and tokens

- Confirm authorization flow, redirect URI, scopes, token endpoint, refresh behavior, and expiration handling.
- Never implement token storage by writing raw secrets to workflow data or logs.
- Prefer managed credentials and supported OAuth configuration. If a provider's flow is unsupported, document the gap before proposing a secure alternative.
- Review credential ownership and what happens when credentials rotate or are revoked.

## Integration test matrix

Test successful response, empty response, invalid input, unauthorized/forbidden, rate limit, transient server failure, timeout, pagination across multiple pages, duplicate webhook delivery, and schema variation when relevant. Use controlled test data and avoid unintended writes to real users or customers.

## Deliverables

Document the API contract, authentication setup without exposing secrets, node configuration, pagination/retry behavior, webhook security, and actual test evidence. Clearly identify any operation that remains unverified.
