# n8n API and Webhook Integrations

Install this ZIP as one individual Claude Skill. Upload the ZIP containing the `n8n-api-webhooks/` folder. Enable it alongside the n8n Skill Router for best routing behavior.
