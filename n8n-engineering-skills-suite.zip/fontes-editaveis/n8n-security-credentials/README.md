# n8n Security and Credentials

Install this ZIP as one individual Claude Skill. Upload the ZIP containing the `n8n-security-credentials/` folder. Enable it alongside the n8n Skill Router for best routing behavior.
