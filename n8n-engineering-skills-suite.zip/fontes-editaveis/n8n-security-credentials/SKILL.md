---
name: n8n-security-credentials
description: Reviews and hardens n8n workflows for credentials, secrets, access control, webhook authentication, sensitive data, privacy, least privilege, and secure deployment.
---

# n8n Security and Credentials

## Purpose

Protect n8n instances, workflows, integrations, and data. Use this skill for credential setup, secrets management, permissions, webhook security, privacy reviews, threat modeling, and hardening.

## Non-negotiable delivery standard: quality over speed

The user's explicit priority is **quality of delivery over speed of execution**. Never rush, skip analysis, omit validation, or choose a fragile shortcut merely to finish sooner. Spend the necessary effort on understanding, architecture, implementation, review, and testing. A smaller correct solution is preferable to a large fragile one; a robust solution is preferable to a fast but unreliable one.

Apply these rules on every task:
- Understand the requested outcome and constraints before changing anything.
- Inspect the actual n8n instance, workflow, node versions, available tools, and integration documentation when access is available. Do not invent access, capabilities, node parameters, or test results.
- Prefer official, current documentation and verify version-sensitive behavior.
- Preserve existing behavior unless the user explicitly asks to change it. Inspect before editing and protect against destructive changes.
- Design for security, reliability, observability, maintainability, and sensible resource use.
- Validate the actual result. Distinguish structural checks, dry runs, test executions, and production verification.
- Never claim completion when an essential requirement remains unimplemented or untested. Report limitations and unresolved risks plainly.

## Execution and safety rules

Use available n8n/MCP/API tools only when they are actually present and authorized. Inspect tool descriptions and input requirements; use the narrowest suitable operation. Do not fabricate tool names or parameters. Do not expose credentials, tokens, secrets, or personal data in outputs or logs. Use n8n credential objects or approved secret stores rather than hardcoding secrets.

Before destructive or externally consequential actions (deleting data/workflows, replacing production configuration, sending messages to real recipients, charging money, publishing content, or activating a production workflow), inspect the impact and obtain explicit user authorization unless the user has already clearly authorized that exact action. Prefer backups, copies, test data, and reversible changes.

When information is missing, make a reasonable, low-risk assumption if it does not materially affect correctness. Ask one concise question only when an essential decision cannot safely be inferred. State material assumptions.

## Definition of done

A task is complete only when the requested outcome is implemented or the remaining blockers are explicit; configuration and connections have been reviewed; representative success and failure paths have been considered; security and operational risks have been checked; and the user receives a truthful summary of what changed, what was tested, what was not tested, and what remains.

## Threat model

Identify assets (credentials, customer data, workflow definitions, execution history), trust boundaries, entry points, actors, permissions, and likely threats. Consider malicious webhook input, prompt injection, compromised integrations, accidental publication, credential leakage, excessive privileges, and unauthorized workflow edits.

## Credentials and secrets

- Use n8n's credential management and supported secret stores.
- Apply least privilege and separate credentials by environment and purpose.
- Never place secrets in Code nodes, static data, plain-text workflow notes, URLs, Git repositories, screenshots, or user-facing reports.
- Avoid exposing credential values in execution logs or error messages.
- Define rotation, revocation, ownership, and incident response expectations.
- Verify that export/import and backup procedures do not expose secrets.

## Webhook and endpoint security

- Use authentication/signature verification supported by the provider.
- Validate payload schemas and reject unexpected inputs.
- Apply replay protection and deduplication where appropriate.
- Avoid leaking internal stack traces, node names, secrets, or sensitive records to callers.
- Review endpoint exposure, TLS, access restrictions, and separation of test/production URLs.

## Data protection

- Collect and retain only necessary data.
- Sanitize logs and notifications; avoid copying full payloads without a need.
- Set execution-data retention according to operational and privacy requirements.
- Prevent cross-user/tenant data access in AI, database, and retrieval workflows.
- Review where data is sent to third-party APIs and model providers.
- Consider applicable privacy obligations based on the user's jurisdiction and use case; do not give unsupported legal assurances.

## Change controls

Review permissions, workflow sharing, instance settings, community nodes, environment variables, backups, and production access where relevant. Flag risky configurations and propose staged remediation. Do not disable production workflows or rotate/revoke live credentials without explicit authorization and a recovery plan.

## Security review output

Deliver findings by severity, evidence, impact, exploitability, recommended fix, and verification method. Separate confirmed vulnerabilities from hardening recommendations and unknowns. Never print actual secrets in the report.
