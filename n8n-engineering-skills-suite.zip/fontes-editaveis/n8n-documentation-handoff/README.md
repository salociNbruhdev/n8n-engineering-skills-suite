# n8n Documentation and Handoff

Install this ZIP as one individual Claude Skill. Upload the ZIP containing the `n8n-documentation-handoff/` folder. Enable it alongside the n8n Skill Router for best routing behavior.
