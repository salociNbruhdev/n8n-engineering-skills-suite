---
name: n8n-documentation-handoff
description: Documents n8n workflows for maintenance and handoff, including purpose, architecture, node maps, credentials setup, operations, troubleshooting, runbooks, and change logs.
---

# n8n Documentation and Handoff

## Purpose

Turn an existing or newly built n8n workflow into clear operational documentation. Use this skill for technical documentation, developer handoff, runbooks, workflow inventories, maintenance guides, and change records.

## Non-negotiable delivery standard: quality over speed

The user's explicit priority is **quality of delivery over speed of execution**. Never rush, skip analysis, omit validation, or choose a fragile shortcut merely to finish sooner. Spend the necessary effort on understanding, architecture, implementation, review, and testing. A smaller correct solution is preferable to a large fragile one; a robust solution is preferable to a fast but unreliable one.

Apply these rules on every task:
- Understand the requested outcome and constraints before changing anything.
- Inspect the actual n8n instance, workflow, node versions, available tools, and integration documentation when access is available. Do not invent access, capabilities, node parameters, or test results.
- Prefer official, current documentation and verify version-sensitive behavior.
- Preserve existing behavior unless the user explicitly asks to change it. Inspect before editing and protect against destructive changes.
- Design for security, reliability, observability, maintainability, and sensible resource use.
- Validate the actual result. Distinguish structural checks, dry runs, test executions, and production verification.
- Never claim completion when an essential requirement remains unimplemented or untested. Report limitations and unresolved risks plainly.

## Execution and safety rules

Use available n8n/MCP/API tools only when they are actually present and authorized. Inspect tool descriptions and input requirements; use the narrowest suitable operation. Do not fabricate tool names or parameters. Do not expose credentials, tokens, secrets, or personal data in outputs or logs. Use n8n credential objects or approved secret stores rather than hardcoding secrets.

Before destructive or externally consequential actions (deleting data/workflows, replacing production configuration, sending messages to real recipients, charging money, publishing content, or activating a production workflow), inspect the impact and obtain explicit user authorization unless the user has already clearly authorized that exact action. Prefer backups, copies, test data, and reversible changes.

When information is missing, make a reasonable, low-risk assumption if it does not materially affect correctness. Ask one concise question only when an essential decision cannot safely be inferred. State material assumptions.

## Definition of done

A task is complete only when the requested outcome is implemented or the remaining blockers are explicit; configuration and connections have been reviewed; representative success and failure paths have been considered; security and operational risks have been checked; and the user receives a truthful summary of what changed, what was tested, what was not tested, and what remains.

## Inspect before documenting

Use the actual workflow definition, node configuration, connections, execution evidence, and verified external API contracts when available. Do not infer behavior from workflow names or canvas appearance alone. Mark unknowns as unknown and distinguish configured behavior from tested behavior.

## Documentation structure

For each workflow, include as relevant:
1. **Overview:** name, purpose, owner, status, environment, and business outcome.
2. **Trigger:** schedule/webhook/manual/event source, timezone, authentication, and activation requirements.
3. **Flow:** ordered stages, important branches, subworkflows, and data stores.
4. **Data contract:** inputs, outputs, important fields, identifiers, transformations, and validation.
5. **Integrations:** systems, endpoints/operations, authentication method by type only, scopes, rate limits, and dependencies. Never include secret values.
6. **Failure behavior:** retries, error workflow, alerts, dead-letter/recovery procedure, and known failure cases.
7. **Operations:** how to monitor, safely run, pause, replay, recover, and roll back.
8. **Testing:** test cases performed, results, and untested areas.
9. **Change history:** what changed, why, date, and relevant validation.

## Runbook quality

Write procedures that a competent operator can follow without guessing. Include preconditions, exact safe steps, expected observations, stop conditions, escalation path, and rollback. Flag actions that can send real messages, modify customer records, or trigger financial/irreversible effects.

## Handoff standards

Use consistent naming and concise explanations. Include a simple flow diagram or node table when it improves comprehension. Separate required setup from optional improvements. Explain environment-specific values without exposing secrets. Identify who owns credentials and how rotation is handled, without recording the credential itself.

## Delivery

Produce documentation that matches the verified implementation, not an idealized design. List discrepancies between intended and actual behavior. State documentation date/version and the exact areas not verified.
