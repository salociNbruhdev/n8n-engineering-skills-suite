---
name: n8n-reliability-errors
description: Designs resilient n8n workflows with retries, error workflows, idempotency, deduplication, backoff, recovery, alerting, queues, and operational monitoring.
---

# n8n Reliability and Error Handling

## Purpose

Make n8n workflows recoverable and predictable under failure. Use this skill for retries, error workflows, idempotency, duplicate events, backoff, partial processing, queue/concurrency issues, alerts, recovery, and monitoring.

## Non-negotiable delivery standard: quality over speed

The user's explicit priority is **quality of delivery over speed of execution**. Never rush, skip analysis, omit validation, or choose a fragile shortcut merely to finish sooner. Spend the necessary effort on understanding, architecture, implementation, review, and testing. A smaller correct solution is preferable to a large fragile one; a robust solution is preferable to a fast but unreliable one.

Apply these rules on every task:
- Understand the requested outcome and constraints before changing anything.
- Inspect the actual n8n instance, workflow, node versions, available tools, and integration documentation when access is available. Do not invent access, capabilities, node parameters, or test results.
- Prefer official, current documentation and verify version-sensitive behavior.
- Preserve existing behavior unless the user explicitly asks to change it. Inspect before editing and protect against destructive changes.
- Design for security, reliability, observability, maintainability, and sensible resource use.
- Validate the actual result. Distinguish structural checks, dry runs, test executions, and production verification.
- Never claim completion when an essential requirement remains unimplemented or untested. Report limitations and unresolved risks plainly.

## Execution and safety rules

Use available n8n/MCP/API tools only when they are actually present and authorized. Inspect tool descriptions and input requirements; use the narrowest suitable operation. Do not fabricate tool names or parameters. Do not expose credentials, tokens, secrets, or personal data in outputs or logs. Use n8n credential objects or approved secret stores rather than hardcoding secrets.

Before destructive or externally consequential actions (deleting data/workflows, replacing production configuration, sending messages to real recipients, charging money, publishing content, or activating a production workflow), inspect the impact and obtain explicit user authorization unless the user has already clearly authorized that exact action. Prefer backups, copies, test data, and reversible changes.

When information is missing, make a reasonable, low-risk assumption if it does not materially affect correctness. Ask one concise question only when an essential decision cannot safely be inferred. State material assumptions.

## Definition of done

A task is complete only when the requested outcome is implemented or the remaining blockers are explicit; configuration and connections have been reviewed; representative success and failure paths have been considered; security and operational risks have been checked; and the user receives a truthful summary of what changed, what was tested, what was not tested, and what remains.

## Failure analysis

Classify each failure by source and recoverability: input/data validation, authentication/authorization, rate limit, network/timeout, transient service failure, permanent business rejection, node configuration, resource exhaustion, or unknown. Avoid retrying permanent errors blindly.

## Retry policy

- Retry only transient/retryable failures.
- Use bounded attempts and exponential backoff with jitter where appropriate.
- Respect `Retry-After` and provider rate-limit guidance.
- Set timeouts and an overall execution budget.
- Avoid retry storms and synchronized bursts.
- Ensure retries cannot duplicate irreversible side effects.
- Route exhausted retries to a recoverable failure path with enough context for investigation.

## Idempotency and deduplication

- Identify stable event IDs or business keys.
- Define the idempotency window and storage mechanism.
- Make writes/upserts safe under repeated delivery where possible.
- Consider race conditions when multiple executions process the same event.
- Ensure replay and manual retry do not create duplicate notifications, orders, charges, or records.

## Error workflows and recovery

- Use an error workflow when it provides centralized handling and fits the deployment model.
- Include workflow/execution identifiers, failed node, sanitized error details, timestamp, correlation ID, and relevant business key.
- Avoid logging secrets, raw credentials, or unnecessary personal data.
- Alert the right operator with actionable context and a runbook link when available.
- Define how to replay, resume, or manually reconcile failed work.
- Separate an error notification failure from the original failure so it does not hide the root cause.

## Operational controls

Review execution timeout, concurrency, queue mode, worker capacity, memory, database pressure, retention, and external service limits when relevant to the observed environment. Do not recommend infrastructure changes without evidence. Track success/failure rate, retries, age of oldest pending work, throughput, latency, and alert noise where measurable.

## Validation scenarios

Simulate transient failure, permanent failure, repeated event, timeout, rate limiting, partial batch failure, downstream outage, and recovery/replay. Verify both the normal route and failure route. Do not use real irreversible actions in tests.

## Delivery

Provide a failure matrix, retry limits, idempotency design, alert content, recovery procedure, and evidence from tests. State what is not recoverable automatically and what operator action is required.
