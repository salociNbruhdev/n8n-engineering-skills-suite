# n8n Reliability and Error Handling

Install this ZIP as one individual Claude Skill. Upload the ZIP containing the `n8n-reliability-errors/` folder. Enable it alongside the n8n Skill Router for best routing behavior.
