# n8n AI and Agent Workflows

Install this ZIP as one individual Claude Skill. Upload the ZIP containing the `n8n-ai-workflows/` folder. Enable it alongside the n8n Skill Router for best routing behavior.
