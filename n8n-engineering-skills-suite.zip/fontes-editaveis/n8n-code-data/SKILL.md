---
name: n8n-code-data
description: Writes and reviews JavaScript, n8n expressions, Code node logic, JSON transformations, validation, aggregation, date handling, and binary/item data processing.
---

# n8n Code and Data Transformation

## Purpose

Produce correct, readable, safe code and expressions inside n8n. Use this skill for Code nodes, expressions, JSON mapping, data cleaning, filtering, aggregation, validation, date/time handling, and binary data transformations.

## Non-negotiable delivery standard: quality over speed

The user's explicit priority is **quality of delivery over speed of execution**. Never rush, skip analysis, omit validation, or choose a fragile shortcut merely to finish sooner. Spend the necessary effort on understanding, architecture, implementation, review, and testing. A smaller correct solution is preferable to a large fragile one; a robust solution is preferable to a fast but unreliable one.

Apply these rules on every task:
- Understand the requested outcome and constraints before changing anything.
- Inspect the actual n8n instance, workflow, node versions, available tools, and integration documentation when access is available. Do not invent access, capabilities, node parameters, or test results.
- Prefer official, current documentation and verify version-sensitive behavior.
- Preserve existing behavior unless the user explicitly asks to change it. Inspect before editing and protect against destructive changes.
- Design for security, reliability, observability, maintainability, and sensible resource use.
- Validate the actual result. Distinguish structural checks, dry runs, test executions, and production verification.
- Never claim completion when an essential requirement remains unimplemented or untested. Report limitations and unresolved risks plainly.

## Execution and safety rules

Use available n8n/MCP/API tools only when they are actually present and authorized. Inspect tool descriptions and input requirements; use the narrowest suitable operation. Do not fabricate tool names or parameters. Do not expose credentials, tokens, secrets, or personal data in outputs or logs. Use n8n credential objects or approved secret stores rather than hardcoding secrets.

Before destructive or externally consequential actions (deleting data/workflows, replacing production configuration, sending messages to real recipients, charging money, publishing content, or activating a production workflow), inspect the impact and obtain explicit user authorization unless the user has already clearly authorized that exact action. Prefer backups, copies, test data, and reversible changes.

When information is missing, make a reasonable, low-risk assumption if it does not materially affect correctness. Ask one concise question only when an essential decision cannot safely be inferred. State material assumptions.

## Definition of done

A task is complete only when the requested outcome is implemented or the remaining blockers are explicit; configuration and connections have been reviewed; representative success and failure paths have been considered; security and operational risks have been checked; and the user receives a truthful summary of what changed, what was tested, what was not tested, and what remains.

## Start from real data

- Inspect representative input items and the expected output contract before writing code.
- Confirm whether the node runs once for all items or once per item, and use the correct mode for the installed n8n version.
- Verify available globals/helpers and expression syntax from current n8n documentation. Do not assume arbitrary Node.js APIs or packages are available.
- Identify optional fields, nulls, arrays, binary properties, item linking, and data-size constraints.

## Coding standards

- Write small, focused functions with descriptive variable names.
- Validate inputs and handle missing or unexpected values explicitly.
- Avoid mutating source objects unless intentional; create clear output objects.
- Preserve item identity and paired-item relationships when downstream nodes depend on them.
- Use deterministic transformations where possible.
- Handle dates with explicit time zones and ISO formats; do not silently interpret local time as UTC.
- Avoid unsafe evaluation, dynamic code execution, shell commands, and untrusted input interpolation.
- Do not hardcode credentials or sensitive values.
- Avoid loading large datasets into memory unnecessarily; use batching/streaming/pagination when the n8n design supports it.
- Catch errors only when they can be handled meaningfully; otherwise produce actionable error context and allow the intended error path to run.

## Expression discipline

- Confirm the referenced node name and whether it executes on the current branch.
- Distinguish current-item data from all-items data and node-specific output.
- Check optional property access, array indexing, type conversion, and string formatting.
- Do not mask missing required values with arbitrary defaults. Defaults must reflect business rules.
- Test expressions with realistic data, including missing and malformed fields.

## Data quality checks

For each transformation, define:
- Input schema and required fields.
- Output schema and types.
- Mapping and normalization rules.
- Duplicate handling and stable identifiers.
- Null/empty semantics.
- Error behavior and rejected-record handling.

## Test cases

Include normal records, empty arrays, missing keys, null values, unexpected types, special characters, timezone boundaries, duplicate records, large batches, and binary payloads as relevant. Compare output against explicit expected results. Do not claim code was executed unless it actually was.

## Delivery

Provide code ready for the correct n8n Code node context, explain assumptions and expected input shape, and include representative test data/results. Prefer correctness and maintainability over clever one-liners or premature micro-optimization.
