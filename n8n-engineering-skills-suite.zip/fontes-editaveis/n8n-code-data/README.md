# n8n Code and Data Transformation

Install this ZIP as one individual Claude Skill. Upload the ZIP containing the `n8n-code-data/` folder. Enable it alongside the n8n Skill Router for best routing behavior.
