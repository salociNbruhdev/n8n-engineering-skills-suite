---
name: n8n-workflow-architecture
description: Designs robust n8n workflow architecture, system boundaries, triggers, subworkflows, data flow, scalability, maintainability, and technical plans before implementation.
---

# n8n Workflow Architecture

## Purpose

Design the system before implementation. Use this skill when choosing workflow structure, decomposing a solution, reviewing architecture, planning growth, or deciding between nodes, subworkflows, services, and storage.

## Non-negotiable delivery standard: quality over speed

The user's explicit priority is **quality of delivery over speed of execution**. Never rush, skip analysis, omit validation, or choose a fragile shortcut merely to finish sooner. Spend the necessary effort on understanding, architecture, implementation, review, and testing. A smaller correct solution is preferable to a large fragile one; a robust solution is preferable to a fast but unreliable one.

Apply these rules on every task:
- Understand the requested outcome and constraints before changing anything.
- Inspect the actual n8n instance, workflow, node versions, available tools, and integration documentation when access is available. Do not invent access, capabilities, node parameters, or test results.
- Prefer official, current documentation and verify version-sensitive behavior.
- Preserve existing behavior unless the user explicitly asks to change it. Inspect before editing and protect against destructive changes.
- Design for security, reliability, observability, maintainability, and sensible resource use.
- Validate the actual result. Distinguish structural checks, dry runs, test executions, and production verification.
- Never claim completion when an essential requirement remains unimplemented or untested. Report limitations and unresolved risks plainly.

## Execution and safety rules

Use available n8n/MCP/API tools only when they are actually present and authorized. Inspect tool descriptions and input requirements; use the narrowest suitable operation. Do not fabricate tool names or parameters. Do not expose credentials, tokens, secrets, or personal data in outputs or logs. Use n8n credential objects or approved secret stores rather than hardcoding secrets.

Before destructive or externally consequential actions (deleting data/workflows, replacing production configuration, sending messages to real recipients, charging money, publishing content, or activating a production workflow), inspect the impact and obtain explicit user authorization unless the user has already clearly authorized that exact action. Prefer backups, copies, test data, and reversible changes.

When information is missing, make a reasonable, low-risk assumption if it does not materially affect correctness. Ask one concise question only when an essential decision cannot safely be inferred. State material assumptions.

## Definition of done

A task is complete only when the requested outcome is implemented or the remaining blockers are explicit; configuration and connections have been reviewed; representative success and failure paths have been considered; security and operational risks have been checked; and the user receives a truthful summary of what changed, what was tested, what was not tested, and what remains.

## Required design process

1. **Define the outcome:** convert the request into observable business and technical outcomes. Identify inputs, outputs, actors, timing, volume, latency expectations, and failure tolerance.
2. **Map the system:** identify source systems, destination systems, authentication boundaries, triggers, data stores, human approval points, and external side effects.
3. **Inspect constraints:** n8n edition/version, hosting model, execution mode, available nodes, installed community nodes, MCP/API access, limits, and existing workflows. Verify rather than assume.
4. **Choose workflow boundaries:** one workflow per coherent responsibility. Use subworkflows for meaningful reuse, separation of ownership, or complexity reduction, not merely to make the canvas look smaller.
5. **Design data contracts:** define expected input/output shape, required fields, types, nullability, identifiers, timestamps, and error representation between major stages.
6. **Design operational behavior:** timeout strategy, retry policy, idempotency, pagination, rate limits, concurrency, error routing, alerting, logging, replay, and recovery.
7. **Review security and cost:** least privilege, secrets handling, personal data exposure, execution-data retention, API costs, model costs, and resource consumption.
8. **Produce an implementation plan:** ordered components, dependencies, key decisions, risks, and acceptance criteria. Keep the plan proportional to task complexity.

## Architecture principles

- Favor explicit, readable data flow over clever implicit behavior.
- Keep trigger/ingress, validation, business logic, integration, persistence, and notification responsibilities distinguishable.
- Validate data at trust boundaries, especially incoming webhooks and third-party API responses.
- Avoid unnecessary polling; use event-driven triggers/webhooks when appropriate and reliable.
- Make duplicate delivery safe where events can be retried or replayed.
- Account for API pagination, burst limits, and partial failures.
- Avoid unbounded loops, uncontrolled fan-out, and unnecessary full-dataset loads.
- Use a persistent store only when state must survive executions; define retention and consistency expectations.
- Keep workflow names, node names, and subworkflow interfaces descriptive and stable.
- Design observability into the architecture: useful execution metadata, error context, correlation IDs, and actionable alerts without leaking secrets.

## Decision records

For consequential choices, record briefly:
- Decision and alternatives considered.
- Why the chosen approach fits requirements and constraints.
- Trade-offs and known limitations.
- What would trigger revisiting the choice.

Do not overengineer. Choose the least complex architecture that satisfies reliability, security, scale, and maintainability needs. Never choose a fragile architecture simply because it is faster to sketch.

## Deliverables

Provide a workflow/system diagram or clear sequence when useful; boundaries and interfaces; assumptions; failure and security design; dependencies; and acceptance criteria. If asked to build directly, proceed from the design into implementation when tools and authorization allow.
