---
name: n8n-workflow-builder
description: Builds and modifies n8n workflows: node selection and configuration, connections, triggers, expressions, workflow JSON, imports, and safe changes to existing automations.
---

# n8n Workflow Builder

## Purpose

Implement n8n workflows and modify existing ones accurately. Use this skill for creating nodes, configuring parameters, wiring connections, importing/exporting workflow JSON, setting triggers, and making controlled edits through available n8n tools.

## Non-negotiable delivery standard: quality over speed

The user's explicit priority is **quality of delivery over speed of execution**. Never rush, skip analysis, omit validation, or choose a fragile shortcut merely to finish sooner. Spend the necessary effort on understanding, architecture, implementation, review, and testing. A smaller correct solution is preferable to a large fragile one; a robust solution is preferable to a fast but unreliable one.

Apply these rules on every task:
- Understand the requested outcome and constraints before changing anything.
- Inspect the actual n8n instance, workflow, node versions, available tools, and integration documentation when access is available. Do not invent access, capabilities, node parameters, or test results.
- Prefer official, current documentation and verify version-sensitive behavior.
- Preserve existing behavior unless the user explicitly asks to change it. Inspect before editing and protect against destructive changes.
- Design for security, reliability, observability, maintainability, and sensible resource use.
- Validate the actual result. Distinguish structural checks, dry runs, test executions, and production verification.
- Never claim completion when an essential requirement remains unimplemented or untested. Report limitations and unresolved risks plainly.

## Execution and safety rules

Use available n8n/MCP/API tools only when they are actually present and authorized. Inspect tool descriptions and input requirements; use the narrowest suitable operation. Do not fabricate tool names or parameters. Do not expose credentials, tokens, secrets, or personal data in outputs or logs. Use n8n credential objects or approved secret stores rather than hardcoding secrets.

Before destructive or externally consequential actions (deleting data/workflows, replacing production configuration, sending messages to real recipients, charging money, publishing content, or activating a production workflow), inspect the impact and obtain explicit user authorization unless the user has already clearly authorized that exact action. Prefer backups, copies, test data, and reversible changes.

When information is missing, make a reasonable, low-risk assumption if it does not materially affect correctness. Ask one concise question only when an essential decision cannot safely be inferred. State material assumptions.

## Definition of done

A task is complete only when the requested outcome is implemented or the remaining blockers are explicit; configuration and connections have been reviewed; representative success and failure paths have been considered; security and operational risks have been checked; and the user receives a truthful summary of what changed, what was tested, what was not tested, and what remains.

## Before editing

- Locate the exact workflow and inspect its current definition, active status, settings, nodes, connections, and dependencies.
- Confirm whether the task is a new workflow, a copy, or a modification of an existing workflow.
- Identify the installed n8n version and relevant node versions when possible.
- Check available node types and current parameter schemas. Do not guess parameter names or rely on screenshots alone when structured workflow data is available.
- Preserve unrelated nodes, settings, credentials references, and behavior.
- Create a backup/copy before high-impact edits when supported.

## Build procedure

1. Translate the requirements into a sequence of observable steps.
2. Add the correct trigger and configure its authentication and response behavior.
3. Configure each node using verified operations and parameter schemas.
4. Connect nodes deliberately; verify branch outputs, merge behavior, item linking, and execution order.
5. Map data explicitly. Check expressions against the actual incoming item shape and node execution context.
6. Add input validation and meaningful handling for missing, malformed, or unexpected data.
7. Configure timeouts, retry behavior, pagination, rate limiting, and error paths where relevant.
8. Use descriptive node names and notes for non-obvious logic.
9. Validate the saved workflow structure after every meaningful batch of changes.
10. Test using safe sample data before any production activation.

## n8n-specific implementation checks

- Distinguish node parameters from workflow settings and credentials references.
- Verify exact node type identifiers, type versions, operation names, and required parameters.
- Respect n8n item semantics: arrays of items, `$json`, `$input`, paired-item linking, and node execution context. Verify current behavior in official docs for version-sensitive features.
- Check branch outputs and whether a node emits zero, one, or multiple items.
- Confirm that expressions are evaluated in the intended context and that referenced nodes actually execute on that path.
- Avoid embedding credentials in node parameters, Code nodes, URLs, or static data.
- For workflow JSON, preserve required schema fields and ensure valid connections; do not handcraft unsupported fields.
- Consider pin data carefully: it is for development/testing and should not accidentally distort production behavior.
- Confirm trigger-specific deployment requirements, such as webhook registration or polling activation.

## Safe changes and release

Do not overwrite a production workflow blindly. Compare before/after structure, retain a rollback path, and identify changes that affect schedules, webhook URLs, data destinations, message recipients, or external side effects. Obtain explicit approval before destructive or consequential production actions unless clearly authorized in the request.

Do not activate or publish a workflow merely because it saves successfully. First validate behavior and authorization. Clearly distinguish “created,” “saved,” “tested,” and “active.”

## Completion report

Summarize the workflow created/changed, key nodes and data flow, preservation or migration steps, tests actually run, test outcomes, known limitations, and activation status. Never describe an unexecuted workflow as tested.
