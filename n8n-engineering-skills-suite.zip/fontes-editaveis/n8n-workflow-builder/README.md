# n8n Workflow Builder

Install this ZIP as one individual Claude Skill. Upload the ZIP containing the `n8n-workflow-builder/` folder. Enable it alongside the n8n Skill Router for best routing behavior.
