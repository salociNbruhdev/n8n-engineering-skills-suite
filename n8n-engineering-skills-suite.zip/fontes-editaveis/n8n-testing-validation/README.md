# n8n Testing and Validation

Install this ZIP as one individual Claude Skill. Upload the ZIP containing the `n8n-testing-validation/` folder. Enable it alongside the n8n Skill Router for best routing behavior.
