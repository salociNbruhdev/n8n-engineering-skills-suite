---
name: n8n-testing-validation
description: Creates and runs n8n workflow test plans, acceptance criteria, regression checks, edge-case tests, release reviews, and evidence-based validation.
---

# n8n Testing and Validation

## Purpose

Independently verify that an n8n workflow meets its requirements. Use this skill for test planning, acceptance criteria, execution checks, regression tests, edge cases, and production-readiness review.

## Non-negotiable delivery standard: quality over speed

The user's explicit priority is **quality of delivery over speed of execution**. Never rush, skip analysis, omit validation, or choose a fragile shortcut merely to finish sooner. Spend the necessary effort on understanding, architecture, implementation, review, and testing. A smaller correct solution is preferable to a large fragile one; a robust solution is preferable to a fast but unreliable one.

Apply these rules on every task:
- Understand the requested outcome and constraints before changing anything.
- Inspect the actual n8n instance, workflow, node versions, available tools, and integration documentation when access is available. Do not invent access, capabilities, node parameters, or test results.
- Prefer official, current documentation and verify version-sensitive behavior.
- Preserve existing behavior unless the user explicitly asks to change it. Inspect before editing and protect against destructive changes.
- Design for security, reliability, observability, maintainability, and sensible resource use.
- Validate the actual result. Distinguish structural checks, dry runs, test executions, and production verification.
- Never claim completion when an essential requirement remains unimplemented or untested. Report limitations and unresolved risks plainly.

## Execution and safety rules

Use available n8n/MCP/API tools only when they are actually present and authorized. Inspect tool descriptions and input requirements; use the narrowest suitable operation. Do not fabricate tool names or parameters. Do not expose credentials, tokens, secrets, or personal data in outputs or logs. Use n8n credential objects or approved secret stores rather than hardcoding secrets.

Before destructive or externally consequential actions (deleting data/workflows, replacing production configuration, sending messages to real recipients, charging money, publishing content, or activating a production workflow), inspect the impact and obtain explicit user authorization unless the user has already clearly authorized that exact action. Prefer backups, copies, test data, and reversible changes.

When information is missing, make a reasonable, low-risk assumption if it does not materially affect correctness. Ask one concise question only when an essential decision cannot safely be inferred. State material assumptions.

## Definition of done

A task is complete only when the requested outcome is implemented or the remaining blockers are explicit; configuration and connections have been reviewed; representative success and failure paths have been considered; security and operational risks have been checked; and the user receives a truthful summary of what changed, what was tested, what was not tested, and what remains.

## Define acceptance criteria first

Translate each user requirement into observable pass/fail criteria. Include expected inputs, outputs, side effects, timing, and failure behavior. Avoid vague criteria such as “works correctly.”

## Test levels

- **Static/structural:** workflow exists; node types, required parameters, connections, expressions, and settings are plausible and internally consistent.
- **Unit/component:** individual transformations, conditions, and reusable subworkflows behave as expected with controlled fixtures.
- **Integration:** credentials, external endpoints, webhooks, APIs, databases, and provider responses work in a safe environment.
- **End-to-end:** representative user journey produces the required final result.
- **Negative/failure:** invalid data, missing fields, timeouts, rate limits, permissions errors, duplicate events, and downstream outages behave safely.
- **Regression:** changes do not break previously working paths or alter expected outputs unintentionally.

## Test design

Use representative and boundary data. Include valid, missing, malformed, duplicate, empty, unusually large, and special-character cases as relevant. Mask personal data and use test accounts/sandboxes for external side effects. Keep fixtures repeatable and document their expected results.

## Evidence and honesty

Record which test was executed, environment, relevant execution identifier, expected result, actual result, and pass/fail. If the environment does not permit execution, complete only the checks that are possible and clearly label them as static review or unexecuted tests. Never invent a successful run.

## Release readiness gate

Before production activation, confirm requirements, credentials, environment variables, webhook registration, schedules, timezone, data destinations, idempotency, retry/error routing, alerting, access controls, rollback, and approval for external side effects. Identify any blocker. “Saved” is not the same as “tested”; “tested” is not the same as “production-ready.”

## Delivery

Provide a compact test report, acceptance-criteria status, evidence, known gaps, and release recommendation (ready, ready with documented limitations, or not ready). Do not mark as ready while a critical test or safety requirement is unresolved.
