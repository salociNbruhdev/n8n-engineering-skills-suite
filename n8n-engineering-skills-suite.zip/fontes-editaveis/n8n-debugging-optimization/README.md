# n8n Debugging and Optimization

Install this ZIP as one individual Claude Skill. Upload the ZIP containing the `n8n-debugging-optimization/` folder. Enable it alongside the n8n Skill Router for best routing behavior.
