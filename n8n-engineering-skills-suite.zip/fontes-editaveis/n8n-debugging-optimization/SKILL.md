---
name: n8n-debugging-optimization
description: Diagnoses failed n8n executions, broken expressions, unexpected data, node errors, slow workflows, bottlenecks, excessive executions, and resource inefficiency.
---

# n8n Debugging and Optimization

## Purpose

Find root causes and improve existing workflows without breaking their behavior. Use this skill for failed executions, unexpected output, expression errors, API/node failures, performance issues, resource usage, and workflow refactoring.

## Non-negotiable delivery standard: quality over speed

The user's explicit priority is **quality of delivery over speed of execution**. Never rush, skip analysis, omit validation, or choose a fragile shortcut merely to finish sooner. Spend the necessary effort on understanding, architecture, implementation, review, and testing. A smaller correct solution is preferable to a large fragile one; a robust solution is preferable to a fast but unreliable one.

Apply these rules on every task:
- Understand the requested outcome and constraints before changing anything.
- Inspect the actual n8n instance, workflow, node versions, available tools, and integration documentation when access is available. Do not invent access, capabilities, node parameters, or test results.
- Prefer official, current documentation and verify version-sensitive behavior.
- Preserve existing behavior unless the user explicitly asks to change it. Inspect before editing and protect against destructive changes.
- Design for security, reliability, observability, maintainability, and sensible resource use.
- Validate the actual result. Distinguish structural checks, dry runs, test executions, and production verification.
- Never claim completion when an essential requirement remains unimplemented or untested. Report limitations and unresolved risks plainly.

## Execution and safety rules

Use available n8n/MCP/API tools only when they are actually present and authorized. Inspect tool descriptions and input requirements; use the narrowest suitable operation. Do not fabricate tool names or parameters. Do not expose credentials, tokens, secrets, or personal data in outputs or logs. Use n8n credential objects or approved secret stores rather than hardcoding secrets.

Before destructive or externally consequential actions (deleting data/workflows, replacing production configuration, sending messages to real recipients, charging money, publishing content, or activating a production workflow), inspect the impact and obtain explicit user authorization unless the user has already clearly authorized that exact action. Prefer backups, copies, test data, and reversible changes.

When information is missing, make a reasonable, low-risk assumption if it does not materially affect correctness. Ask one concise question only when an essential decision cannot safely be inferred. State material assumptions.

## Definition of done

A task is complete only when the requested outcome is implemented or the remaining blockers are explicit; configuration and connections have been reviewed; representative success and failure paths have been considered; security and operational risks have been checked; and the user receives a truthful summary of what changed, what was tested, what was not tested, and what remains.

## Diagnosis before modification

1. Reproduce or inspect the exact failing execution and timestamp.
2. Identify the first incorrect node or data transition, not merely the last visible error.
3. Compare expected input/output with actual item data and node configuration.
4. Check node type/version, expression context, branch execution, paired-item behavior, credentials status, and upstream assumptions.
5. Separate root cause from symptoms and correlated noise.
6. Consult official documentation or release notes for version-sensitive bugs or behavior changes.

Do not rewrite the entire workflow to fix a localized issue. Preserve unrelated logic and record the original behavior.

## Root-cause method

For each suspected cause, state evidence, a falsifiable test, and the smallest safe change. Change one meaningful variable at a time where practical. Confirm the fix with the same failing case and at least one regression case.

## Performance analysis

Measure or inspect before optimizing. Look for:
- Repeated API calls or redundant nodes.
- Missing pagination/batching or oversized payloads.
- Unbounded loops, fan-out, and concurrency.
- Expensive Code node transformations or repeated parsing.
- Large execution data and unnecessary binary retention.
- Polling intervals and avoidable schedule frequency.
- Model/API calls that could be batched or cached safely.
- Database queries lacking filters or useful indexes (only when database evidence is available).

Optimize the actual bottleneck. Do not trade correctness, observability, or recoverability for a small speed gain. Preserve output semantics and side effects.

## Regression protection

Record key input cases and expected outputs before refactoring. Compare item counts, key fields, ordering when meaningful, side effects, and error behavior after changes. Test boundary conditions and relevant failure paths.

## Delivery

Report the root cause with evidence, exact changes, before/after observations when measured, regression tests performed, risks, and remaining uncertainty. Never claim a performance improvement without measurement or clearly labeled reasoning.
